//
// Created by jan on 10/15/22.
//

#ifndef IFJ_PROJECT_RECURSIVE_DESCENT_H
#define IFJ_PROJECT_RECURSIVE_DESCENT_H

#include "token_stack.h"
#include "scanner.h"
#include "ast.h"

int get_token_rec(FILE *input_file, Token_stack *token_stack);

int analyse_expression(FILE *input_file, Token_stack *token_stack, int first_token_same);

int analyse_return(FILE *input_file, Token_stack *token_stack);

int analyse_arg(FILE *input_file, Token_stack *token_stack);

int analyse_assign(FILE *input_file, Token_stack *token_stack);

int analyse_return_type(FILE *input_file, Token_stack *token_stack, struct tree_node * return_type);

int analyse_param(FILE *input_file, Token_stack *token_stack);

int analyse_body(FILE *input_file, Token_stack *token_stack);

int analyse_prog(FILE *input_file, Token_stack *token_stack, struct tree_node * tree);

int analyse_prolog(FILE* input_file , Token_stack *token_stack, struct tree_node * tree);

int analyse_syntax(FILE* input_file);


#endif //IFJ_PROJECT_RECURSIVE_DESCENT_H
