//
// Created by Martin Soukup
//

#include "ast.h"


void ast_test(struct tree_node * tree)
{
	struct tree_node * tmp = tree->tail_child;
	while( 1 )
	{
		printf("Funkce : %s\n", tmp->data->value);
		printf("Název : %s\n", tmp->head_child->data->value);
		printf("Argumenty : %s\n", tmp->head_child->next_sibling->data->value);
		printf("Return type : %s", tmp->head_child->next_sibling->next_sibling->data->value);
		return;
	}
	
}

//predam root kde je hlavni uzel funkce
/*struct tree_node * ast_parent( struct tree_node *tree, int type, char * value)
{
	//mam root ve kterem je body a jeho syny ale nevim ktery je volny
	//tree = check_sons( tree, type, value);
	printf("%d", tree->head_child->data->type );

	return tree;
	
}*/


//TODO DO SYNTAKTICKÉ SI DODĚLAT ABY MI NA KONCI TÉ KONTROLY BYLO PŘEDÁNY VŠECHNY INFORMACE POTŘEBNÉ PRO SESTAVENÍ
